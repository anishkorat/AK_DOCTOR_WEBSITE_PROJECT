<?php
session_start();
if(!isset($_SESSION['username']))
{
  echo "you are logout";
  header('location:login.php');
}
?> 

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="s.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
<style>

</style>
 </head>
<body>

<!-- <div class="topnav" id="myTopnav" style=" font-family: cursive;background-color:#2B3856">  -->
<div class="topnav" id="myTopnav" style=" font-family: cursive;background-color:#3a4e70">
 <a style="margin-right:40%;color:#E6BF83;font-weight:bold;font-size:18px">Hello , <?php  echo $_SESSION['username'];  ?></a>
  <!-- <a href="#" class="active">Book Appoinment</a> -->
  <a href="adddoctor.php">Add Doctor</a>
  <a href="#">view Doctor</a>
  <a href="#">View Appoinment</a>
  <a href="#">View Feedback</a>
  <a href="logout.php">Logout</a>
  

  
  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
</div> 
<!-- <h1>HELLO THIS IS <?php  /* echo $_SESSION['username']; */ ?></h1> -->


<!-- <a href="mailto:anishkorat011@gmail.com">hege@example.com</a></p> -->


<!-- <a href="logout.php">logout</a> -->









 <script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>

</body>
</html> 