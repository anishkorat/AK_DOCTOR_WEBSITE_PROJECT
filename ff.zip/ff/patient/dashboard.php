<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>mms-patient</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="../style.css">
</head>
<body>


	<?php include('i.php'); ?>






	<!-- this is for donor registraton -->
	<div class="dashboard" style="background-color:#fff;">
		<h3 class="text-center" style="background-color:#272327;color: #fff;padding: 5px;">Welcome to Your Panel</h3>
		<img src="dash1.jpg" alt="logo.png img" class="img-responsive" style="margin-left:440px;width:300px;">
		
		
			
		
	</div>
	





<script src="js/bootstrap.min.js"></script>


</body>
</html>
