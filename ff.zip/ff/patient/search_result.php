<?php if(!isset($_SESSION)){
	session_start();
	}  
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel = "stylesheet" 
         href = "https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" 
         integrity = "sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" 
         crossorigin = "anonymous">
    <title>Search_result</title>
</head>
<body>
<div class = "container-fluid">
<!-- <div class="search form-group" > -->
<h3 class="text-center" style="background-color:#272327;color: #fff;padding: 5px;margin-top:25px;">Search result</h3>
<?php
					

					/* $emailquery = "select doc_id,dname,dob,age,phone,gender,email,expertise,pic from doctor where expertise= '" . $_POST["expertise"]."' "; */
					
				/* 	$count = mysqli_num_rows($result); */
?>
					<!-- <div class="table-responsive" style="margin-top:25px;border-radius:5px;"> -->
					<table class="table table-hover table-striped" style="margin-top:35px;border-radius:15px;">
						<thead >
						<tr class="table-primary">
								<th>Doc_Id</th>
								<th>Name</th>
								<th>Date of Birth</th>
								<th>Age</th>
								<th>Mobile No.</th>
								<th>Gender</th>
								
								<th>Expertise in</th> 
								<th>Email</th>
								<th>Image</th>
								<th>Book</th>
								
						</tr>
						</thead>
						<tbody>
							<?php
								include 'connection.php';
								$selectquery = "select doc_id,dname,dob,age,phone,gender,expertise,email,pic from doctor where expertise= '" . $_POST["expertise"]."' ";
                    			$query = mysqli_query($con,$selectquery);
								/* $result = mysqli_num_rows($query); */
								//$result = mysqli_fetch_array($query);

								if(mysqli_num_rows($query) > 0)
								{
										foreach($query as $row)
										{
											//echo $row['doc_id'];
											?>

											<tr>
												<td><?php echo $row['doc_id'];?></td>
												<td><?php echo $row['dname'];?></td>
												<td><?php echo $row['dob'];?></td>
												<td><?php echo $row['age'];?></td>
												<td><?php echo $row['phone'];?></td>
												<td><?php echo $row['gender'];?></td>
												<td><?php echo $row['expertise'];?></td>
												<td><?php echo $row['email'];?></td>
												
											
												<td>
													<img src = "<?php echo "../admin/".$row['pic'];?>" alt="erro" width="50" height="50" />
												</td>
												<td>
													<a href="booking.php?doc_id=<?php echo $row['doc_id'] ?>" class="btn btn-dark">Book</a>
												</td>
											</tr>
											
							
					
											<?php
										}
										
								}
								else
								{
									?>
									
									
										<p>Sorry, No match found for your search result..!!!</p>
									
									<?php
								}

								
							?>
										</tbody>
						</table>
					<!-- </div> -->
					

<!-- </div> -->
</div>
</body>
</html>


							