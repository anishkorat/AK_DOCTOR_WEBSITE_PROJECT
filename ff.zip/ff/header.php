<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
<style>

</style>
 </head>
<body>
<header>
<!-- <div class="topnav" id="myTopnav" style=" font-family: cursive;background-color:#2B3856">  -->
<div class="topnav" id="myTopnav" style=" font-family: cursive;background-color:#3a4e70">
 <a style="margin-right:40%;color:#E6BF83;font-weight:bold;font-size:18px">@K CLINIC</a>
  <a href="index.php" class="active">Home</a>
  <a href="#">About Us</a>
  <a href="#">Find doctor</a>
  <a href="#">Conatct Us</a>

  <div class="dropdown">
    <button class="dropbtn">Book Appoinment
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="patient/login.php">Patient Login</a>
      <a href="admin/login.php">Admin Login</a>
      <a href="doctor/login.html">Doctor Login</a>
    </div>
  </div> 
  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
</div> 
</header>
<!-- <main>
  <div class="bg__img">
    <img src="img11.jpg" alt="">
  </div>
</main> -->
<footer>

</footer>
<!-- <a href="mailto:anishkorat011@gmail.com">hege@example.com</a></p> -->












 <script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>

</body>
</html> 