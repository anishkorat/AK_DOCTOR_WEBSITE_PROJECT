<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>Login Form</title>
    <style>
      /*    *{
            font-family:Georgia, 'Times New Roman', Times, serif;
            margin: 0;
            padding: 0;
            
        }
        body{
            background-image: url(img14.jpg);
           margin-top: 20px;
        }
        .form-bg{
                   width: 400px;
                   height: 400px;
                   background-color:rgb(0,0,0,0.5);
            
                   transform: translate(-50%,-50%);
                   top:50%;
                   left:50%;
                   position: absolute;
                   box-shadow: 6px 6px 15px black;
                   transform: translate;
                   border-radius: 15px;}
        form{
                margin: 30px;}
                form div{
                margin-top: 10px;}
                a{color: bisque;}
                a:hover{
                color:aquamarine}
                #user,#pwd{
                border-bottom: 2px solid black;}
                label{color:whitesmoke} */
                *{
            font-family:Georgia, 'Times New Roman', Times, serif;
            margin: 0;
            padding: 0;
            
        }
        body{
            background-image: url(img14.jpg);
           margin-top: 20px;
        }
        .form-bg{
                   width: 400px;
                   height: 400px;
                   background-color:rgb(0,0,0,0.5);
            
                   transform: translate(-50%,-50%);
                   top:50%;
                   left:50%;
                   position: absolute;
                   box-shadow: 6px 6px 15px black;
                   transform: translate;
                   border-radius: 15px;}
        form{
                margin: 30px;}
                form div{
                margin-top: 10px;}
                a{color: bisque;}
                a:hover{
                color:aquamarine}
                #user,#pwd{
                border-bottom: 2px solid black;}
                label{color:whitesmoke}
    </style>
</head>
<body>
<?php
include 'connection.php';

if(isset($_POST['log']))
{
  $email=$_POST['ename'];
  $ppwd=$_POST['pwd'];

  $email_search= "select * from reg where email='$email' ";
  $query = mysqli_query($con, $email_search);
  $e_count = mysqli_num_rows($query);

  if($e_count)
  {
    $e_pass = mysqli_fetch_assoc($query);
    $db_pass = $e_pass['pwd'];

    $_SESSION['username'] = $e_pass['name'];
    $_SESSION['email']= $e_pass['email'];
   // $pass_decode = password_verify($ppwd,$db_pass);
    
    if($ppwd == $db_pass)
    {
      echo "Login Successfully.";
      ?>
      <script>
         location.replace('dashboard.php');
      </script>
      <?php
    }
    else
    {
      //echo "Password Incorrect";
      ?>
      <script>
          alert("Password Incorrect");
      </script>
      <?php
    }
  }
  else
  {
    //echo "Invalid Email";
    ?>
      <script>
          alert("Invalid Email");
      </script>
      <?php
  }



}

?>


    <div class="container">
        <div class="form-bg">
            <!-- <h2 align="center" style="margin-top: 10px;color:black; text-shadow: 2px 2px 4px wheat;" >Login Form</h2> -->
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" name="myform" method="POST">
            <div class="form-group">
                <label for="user">Username</label>
                <input type="text" class="form-control" id="user" placeholder="Enter Username" name="ename" required>
              </div>

              <div class="form-group">
                <label for="pwd">Password</label>
                <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pwd" required>
              </div>
              <div class="form-group">        
                
                <div class="checkbox" >
                  <label><input type="checkbox" name="remember" > Remember me</label>
                  <a href="forget.html" align="center" style="margin-left: 90px;">Forget Password</a>
                </div>
              
            </div>
              <div>
                <button type="submit" name="log" class="btn btn-dark btn-block" style="margin-top: 10px;">login</button>
               
              </div>
                <br>
              <div class="text-center">
                <!-- <a href="forget.html" align="center">Forget Password</a> -->
               
                 <p>Not a member? <a href="reg2.php">Register</a></p>
            </div>
        </form>
    </div>
    </div>
</body>
</html>