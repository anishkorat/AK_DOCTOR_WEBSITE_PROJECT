-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 01, 2022 at 07:02 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ff`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `username` varchar(25) NOT NULL,
  `pwd` varchar(25) NOT NULL,
  `type` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`username`, `pwd`, `type`) VALUES
('adnim', 'adnim', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `booking_id` int(22) NOT NULL,
  `dname` varchar(22) NOT NULL,
  `dcontact` varchar(11) NOT NULL,
  `expertise` varchar(25) NOT NULL,
  `pname` varchar(25) NOT NULL,
  `pcontact` varchar(11) NOT NULL,
  `email` varchar(25) NOT NULL,
  `address` varchar(200) NOT NULL,
  `date` varchar(22) NOT NULL,
  `time` varchar(22) NOT NULL,
  `userid` int(22) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`booking_id`, `dname`, `dcontact`, `expertise`, `pname`, `pcontact`, `email`, `address`, `date`, `time`, `userid`) VALUES
(19, 'aaa', '9726609315', 'Bone', 'KORAT ANISH BHARATBHAI', '1234567890', 'nayan123@gmail.com', '404 marutisadanapp.\r\nSantiniketan Soc.', '2022-09-06', '12:00 AM', 111),
(24, 'aaa', '9726609315', 'Bone', 'KORAT ANISH BHARATBHAI', '1234567890', 'nayan123@gmail.com', '404 marutisadanapp.\r\nSantiniketan Soc.', '2022-09-05', '12:30 AM', 111),
(25, 'eee', '9726609315', 'Medicine', 'KORAT ANISH BHARATBHAI', '1234567890', 'nayan123@gmail.com', '404 marutisadanapp.\r\nSantiniketan Soc.', '2022-09-09', '12:00 AM', 555),
(27, 'bbb', '9726609315', 'Heart', 'KORAT ANISH BHARATBHAI', '1234567890', 'nayan123@gmail.com', '404 marutisadanapp.\r\nSantiniketan Soc.', '2022-09-21', '12:30 AM', 222),
(28, 'bbb', '9726609315', 'Heart', 'KORAT ANISH BHARATBHAI', '1234567890', 'nayan123@gmail.com', '404 marutisadanapp.\r\nSantiniketan Soc.', '2022-09-21', '12:30 AM', 222),
(29, 'eee', '9726609315', 'Medicine', 'KORAT ANISH BHARATBHAI', '1234567890', 'anishkorat011@gmail.com', '404 marutisadanapp.\r\nSantiniketan Soc.', '2022-09-27', '12:00 AM', 555);

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `doc_id` int(10) NOT NULL,
  `dname` varchar(25) NOT NULL,
  `dob` varchar(20) NOT NULL,
  `age` int(10) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `expertise` varchar(50) NOT NULL,
  `ads` varchar(100) NOT NULL,
  `userid` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pwd` varchar(20) NOT NULL,
  `pic` varchar(222) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`doc_id`, `dname`, `dob`, `age`, `phone`, `gender`, `expertise`, `ads`, `userid`, `email`, `pwd`, `pic`) VALUES
(5, 'eee', '2022-08-19', 33, '9726609315', 'Male', 'Medicine', '404 marutisadanapp.\r\nSantiniketan Soc.555', '555', 'nayan123@gmail.com', '11111111111111111111', 'upload/a3.jpg'),
(6, 'bbb', '2022-08-05', 2, '9726609315', 'Male', 'Heart', '404 marutisadanapp.\r\nSantiniketan Soc.', '222', 'bbb111@gmail.com', '11111111', 'upload/a3.jpg'),
(7, 'ccc', '2022-08-14', 12, '9726609315', 'Male', 'Medicine', '404 marutisadanapp.\r\nSantiniketan Soc.', '333', 'ccc111@gmail.com', '11111111', 'upload/sig logo.jpg'),
(9, 'eee', '2022-08-04', 1, '9726609315', 'Male', 'Medicine', '404 marutisadanapp.\r\nSantiniketan Soc.', '666', 'eee111@gmail.com', '11111111', 'upload/God Wallpaper_1610809106~2.jpg'),
(10, 'aaa', '2022-08-10', 23, '9726609315', 'Male', 'Bone', '404 marutisadanapp.\r\nSantiniketan Soc.', '111', 'aaa123@gmail.com', '11111111', 'upload/2015 - 1 (5).jpg');

-- --------------------------------------------------------

--
-- Table structure for table `reg`
--

CREATE TABLE `reg` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `date` varchar(25) NOT NULL,
  `age` int(11) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `gender` varchar(25) NOT NULL,
  `blood` varchar(35) NOT NULL,
  `ads` varchar(70) NOT NULL,
  `email` varchar(25) NOT NULL,
  `pwd` varchar(20) NOT NULL,
  `cpwd` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reg`
--

INSERT INTO `reg` (`id`, `name`, `date`, `age`, `phone`, `gender`, `blood`, `ads`, `email`, `pwd`, `cpwd`) VALUES
(5, 'anishkorat', '2003-05-02', 21, '9426688792', 'Male', 'O-', '404 marutisadanapp.Santiniketan Soc.', 'anishkorat0111@gmail.com', '11111111', '11111111');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`doc_id`);

--
-- Indexes for table `reg`
--
ALTER TABLE `reg`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `booking_id` int(22) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `doc_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `reg`
--
ALTER TABLE `reg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
