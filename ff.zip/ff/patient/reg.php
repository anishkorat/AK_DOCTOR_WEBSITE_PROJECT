<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"> -->


<script src="jq.js"></script>
<script>
$(document).ready(function(){
	$("#condition").click(function(){
		var st;
		if(st==this.checked)
		{
			$(":submit").attr("disabled",true);
		}
		else{

			$(":submit").removeAttr("disabled");
		}
	}
	);


});
</script>

<script type="text/javascript">

function fun()
    {
        var regEx = /^[A-Za-z]+$/;
        var name=document.myform.fname.value;
        var birth=document.myform.dob.value;
        var age=document.myform.age.value;
        var mob=document.myform.phone.value;
        var email=document.myform.email.value;
        var atposition=email.indexOf("@");
        var dotposition=email.lastIndexOf(".");


	    var firstpassword=document.myform.pwd.value;
	    var secondpassword=document.myform.pwd1.value;


        if(isNaN(mob))
        {

            alert("ENTER THE VALID MOBIEL NUMBER(LIKE :: 9879936272)");
            return false;

        }
        else{

            /* if((mob.length > 10))
            {
                alert("YOUR MOBILE NUMBER MUST BE 1 TO 10 INTEGER.");
                return false;
            } */
            if((mob.length == 1) || (mob.length == 2) || (mob.length == 3)|| (mob.length == 4)|| (mob.length == 5)|| (mob.length == 6)|| (mob.length == 7)|| (mob.length == 8)|| (mob.length == 9))
            {
                alert("YOUR MOBILE NUMBER MUST BE 10 DIGIT.");
                return false;
            }

            return true;
        }


        if(atposition<1 || dotposition<atposition+2 || dotposition+2>=email.length)
        {
            alert("Please enter a valid e-mail address \n atpostion:"+atposition+"\n dotposition:"+dotposition);
            return false;
        }
        else{
            return true;
        }






        if(age == "")
        {
            alert("PLEASE SELECT AGE");
            return false;
        }
        else{
            return true;
        }
        if(birth == "")
        {
            alert("PLEASE SELECT BIRTH DATE");
            return false;
        }
        else{
            return true;
        }
        if(!isNaN(name))
        {
            alert("PLEASE ENTER LETTERS ONLY.")
            return false;
        }
        else{
            return true;
        }

        if(firstpassword==secondpassword)
	    {
		return true;
	    }
	    else
	    {
		alert("password must be same!");
		return false;
	    }



    /* ----------------------------------------------------------------------- */
      /*
        if(!isNaN(name))
        {
            alert("PLEASE ENTER LETTERS ONLY.")
            return false;
        }

       else if(age == "")
        {
            alert("PLEASE SELECT AGE");
            return false;
        }

        else if(atposition<1 || dotposition<atposition+2 || dotposition+2>=email.length)
        {
            alert("Please enter a valid e-mail address \n atpostion:"+atposition+"\n dotposition:"+dotposition);
            return false;
        }

        else if(birth == "")
        {
            alert("PLEASE SELECT BIRTH DATE");
            return false;
        }

        else if(isNaN(mob).length<10)
        {

            alert("PHONE NUMBER IS MUST BE 10 DIGIT.");
            return false;
        } */
      /*  else if(pwd == pwd1)
       {
            alert("password must be same!");
		    return false;
       } */






}



</script>

</head>
<!-- <?php 

   /*  if(isset($_POST['sub']))
    {
        $uname=$_POST['name'];
        $uname=$_POST['dob'];
        $uname=$_POST['age'];
        $uname=$_POST['phone'];
        $uname=$_POST['gen'];
        $uname=$_POST['bld'];
        $uname=$_POST['ads'];
        $uname=$_POST['email'];
        $uname=$_POST['pwd'];
        $uname=$_POST['pwd1'];
        
    } */

?>
 -->

<body>
    <div class="container">
        <div class="form-bg">
        <form action="action.html" onsubmit="return fun()" name="myform" method="POST">
            <div class="form-group">
                <input type="text" class="form-control" id="name" placeholder="Enter Name" name="fname" required autofocus>
            </div>
            <div class="form-group">
                <input type="date" class="form-control" id="dob" placeholder="Date of Birth" name="dob" >
            </div>
            <div class="form-group">
                <input type="number" class="form-control" id="age" placeholder="Age" name="age" >
            </div>
                 <div class="form-group">
                <input type="text" class="form-control" id="mphone" placeholder="Phone Number" name="phone" >
            </div>
        <div class="form-group">

                <select class="form-control input-sm" name="gen"  style="padding:0 7px 3px;" id="i1" required>
                    <option>Gender</option>
                    <option value="Male">Male</option>
                    <option value="FeMale">Female</option>
                    <option value="Other">Other</option>
                  </select>

              </div>
                   <div class="form-group">

                <select class="form-control input-sm" name="bld" style="padding:0 7px 3px;" required>
                    <option>Blood Group</option>
                    <option value="O-">O-</option>
                    <option value="O+">O+</option>
                    <option value="A-">A-</option>
                    <option value="A+">A+</option>
                    <option value="B-">B-</option>
                    <option value="B+">B+</option>
                    <option value="AB-">AB-</option>
                    <option value="AB+">AB+</option>

                  </select>

              </div>
              <div class="form-group">
                            <textarea id="ads" class="md-textarea form-control" rows="2" placeholder="Address" name="ads" required></textarea>
              </div>
              <div class="form-group">
                <input type="email" class="form-control" id="email" placeholder="Enter Your Email" name="email" required>
             </div>
             <div class="form-group">
                <input type="password" class="form-control"  id="p1" placeholder="Enter Password" name="pwd" minlength="8" required>
             </div>
             <div class="form-group">
                <input type="password" class="form-control" id="p2" placeholder="Repeat Password" name="pwd1" minlength="8" required>
             </div>
             <div class="form-group">

                  <div class="checkbox" style="color:white">
                    <label><input type="checkbox" name="remember"  id="condition">  By creating an account you agree to our  <a href="#" style="color:#0020C2">  Terms & Conditions</a></label>
                  </div>

              </div>
             <div>
                <button type="submit" class="btn" name="sub" disabled>REGISTER</button>
      
                <button type="reset" class="btn" style="background-color: #2B3856;color: aliceblue;">RESET</button>
            </div>
        </form>
        </div>
    </div>
</body>
</html>