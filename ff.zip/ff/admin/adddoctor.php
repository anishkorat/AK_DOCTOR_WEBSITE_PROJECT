<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>
         *{
            font-family:Georgia, 'Times New Roman', Times, serif;
            margin: 0;
            padding: 0;
            
        }
        body{
            background-image: url(img14.jpg);
           margin-top: 20px;
        }
        .form-bg{
          /*   background-color:#ffdab9; */
             /*  border: 2px solid #87CEFA; */
                  /*    box-shadow:5px 5px 30px #87cefa; */
          
                  /* background-color:#6D7B8D;
            border-radius: 15px;
            padding: 20px;  
            margin-top: 30px;
            border: 2px solid #98AFC7; */

            background-color:rgb(0,0,0,0.5);
            box-shadow: 6px 6px 15px black;
            padding: 20px; 
            border-radius: 15px;
            margin-top: 30px;
            position: absolute;
            transform: translate(-50%,-50%);
            top:50%;
            left:50%;
            transform: translate;
            
        }
    </style>
<script type="text/javascript">
    function fun()
    {
        var regEx = /^[A-Za-z]+$/;
        var name=document.myform.dname.value;
        var birth=document.myform.dob.value;
        var age=document.myform.age.value;
        var mob=document.myform.phone.value;
        var email=document.myform.email.value;
        var atposition=email.indexOf("@");
        var dotposition=email.lastIndexOf(".");

        var firstpassword=document.getElementById("pwd").value;


        if(!isNaN(name))
        {
            alert("PLEASE ENTER LETTERS ONLY.")
            return false;
        }
        else if(birth == "")
        {
            alert("PLEASE SELECT BIRTH DATE");
            return false;
        }
        else if(age == "")
        {
            alert("PLEASE SELECT AGE");
            return false;
        }
        else if(isNaN(mob) || mob == "" || (mob.length == 1) || (mob.length == 2) || (mob.length == 3)|| (mob.length == 4)|| (mob.length == 5)|| (mob.length == 6)|| (mob.length == 7)|| (mob.length == 8)|| (mob.length == 9))
        {

            alert("ENTER THE VALID MOBIEL NUMBER(LIKE :: 9879936272)");
            return false;
           /*   if((mob.length == 1) || (mob.length == 2) || (mob.length == 3)|| (mob.length == 4)|| (mob.length == 5)|| (mob.length == 6)|| (mob.length == 7)|| (mob.length == 8)|| (mob.length == 9))
            {
                alert("YOUR MOBILE NUMBER MUST BE 10 DIGIT.");
                return false;
            } */


        }
        else if(atposition<1 || dotposition<atposition+2 || dotposition+2>=email.length)
        {
            alert("Please enter a valid e-mail address \n atpostion:"+atposition+"\n dotposition:"+dotposition);
            return false;
        }
        else
        {
            return true;
        }

    }
</script>
</head>
<body>
<?php
include 'connection.php';

if(isset($_POST['sub']))
{
        $names=mysqli_real_escape_string($con, $_POST['dname']);
        $dobs=mysqli_real_escape_string($con, $_POST['dob']);
        $ages=mysqli_real_escape_string($con, $_POST['age']);
        $phones=mysqli_real_escape_string($con, $_POST['phone']);
        $gens=mysqli_real_escape_string($con, $_POST['gen']);
        $exper=mysqli_real_escape_string($con, $_POST['expertise']);
        $adss=mysqli_real_escape_string($con, $_POST['ads']);
        $uid=mysqli_real_escape_string($con, $_POST['userid']);
        $emails=mysqli_real_escape_string($con, $_POST['email']);
        $pwds=mysqli_real_escape_string($con, $_POST['pwd']);

        $files =$_FILES['pic'];
        $filename = $files['name'];
        $fileerror = $files['error'];
        $filetemp = $files['tmp_name']; 

        $fileext = explode('.',$filename);
        $filecheck = strtolower(end($fileext));

        $fileextstored = array('png','jpg','jpeg');
        /* if(in_array($filecheck,$fileextstored))
        {
            $destinationfile='upload/'.$filename;
            move_uploaded_file($filetemp,$destinationfile);
        } */




        $emailquery = "select * from doctor where email='$emails' OR userid='$uid' ";
        $query = mysqli_query($con,$emailquery);

        $emailcount = mysqli_num_rows($query);

        if($emailcount>0)
        {
            ?>
            <script>
                alert("Sorry, Userid or E-mail already exist!");
            </script>
            <?php
        }
        else
        {
            if($fileerror == 0)
            {
                $destinationfile='upload/'.$filename;
                move_uploaded_file($filetemp,$destinationfile);
            
                $insertquery="insert into doctor(dname,dob,age,phone,gender,expertise,ads,userid,email,pwd,pic) values ('$names','$dobs','$ages','$phones','$gens','$exper','$adss','$uid','$emails','$pwds','$destinationfile')";
                $iquery = mysqli_query($con, $insertquery);


                if($iquery)
                {
                        ?>
                        <script>
                            alert("New Doctor Has been Added Successfully!");
                        </script>
                        <?php
                }
                    else

                    {   
                        ?>
                        <script>
                            alert("inserted not done");
                        </script>
                        <?php
                    }
            }
            else
            {
                ?>
                <script>
                alert("Sorry there was an error!!!!") ;
                </script>
                <?php
            }
            
            
        }
    } 




?>



<div class="container">
        <div class="form-bg">
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" onsubmit="return fun()" name="myform" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                
                <input type="text" class="form-control" id="name" placeholder="Enter Doctor Name" name="dname" required autofocus>
            </div>
            <div class="form-group">
             
                <input type="date" class="form-control" id="dob" placeholder="Date of Birth" name="dob" >
            </div>
            <div class="form-group">
           
                <input type="number" class="form-control" id="age" placeholder="Age" name="age" >
            </div>
            <div class="form-group">
           
               <input type="text" class="form-control" id="mphone" placeholder="Phone Number" name="phone" >
            </div>
            <div class="form-group">
                        
            <select class="form-control input-sm" name="gen"  style="padding:0 7px 3px;" id="i1" required="">
                    <option value="">Gender</option>
                    <option value="Male">Male</option>
                    <option value="FeMale">Female</option>
                    <option value="Other">Other</option>
                  </select>
                 
              </div>
              <div class="form-group">
                        
               
                  <select class="form-control input-sm" name="expertise" style="padding:0 7px 3px;" required="">
                                        <option value="">-Expert in-</option>
										<option value="Medicine">Medicine</option>
										<option value="Heart">Heart</option>
										<option value="Bone">Bone</option>
										<option value="kedney">kedney</option>
                                        <option value="Cardiologist">Cardiologist</option>
                                        <option value="Plastic Surgeon">Plastic Surgeon</option>
                                        <option value="Neurologist">Neurologist</option>
                                        <option value="General Physician">General Physician</option>
                  </select>
                 
              </div>
              <div class="form-group">
                      <!--       <textarea id="ads" class="md-textarea form-control" rows="2" placeholder="Address" ></textarea> -->
                            <textarea id="ads" class="md-textarea form-control" rows="2" placeholder="Address" name="ads" required></textarea>
              </div>
              <div class="form-group">
           
                     <input type="text" class="form-control" id="uid" placeholder="Enter Userid" name="userid" >
             </div>
              <div class="form-group">
               
                <input type="email" class="form-control" id="email" placeholder="Enter Your Email" name="email" >
             </div>
             <div class="form-group">
                <input type="password" class="form-control" id="pwd" placeholder="Enter Password" name="pwd" minlength="8"  required>
             </div>
             
             <div class="form-group">
             <input type="file" class="form-control" id="pic" value="" name="pic" style="height:45px" required>
             </div>
             <div class="form-group">        
                
                  <div class="checkbox" style="color:white">
                    <label><input type="checkbox" name="remember" id="condition">  By creating an account you agree to our  <a href="#" style="color:#0020C2">  Terms & Conditions</a></label>
                  </div>
                
              </div>
             <div>
                <button type="submit" class="btn " style="background-color: #2B3856;;color: aliceblue;" name="sub" >ADD DOCTOR</button>
                <!-- <button type="submit" class="btn " style="background-color: #2B3856;;color: aliceblue;" name="sub" >REGISTER</button> -->
                <button type="reset" class="btn " style="background-color: #2B3856;;color: aliceblue;">RESET</button>
            </div>
        </form>
        </div>
    </div>
</body>
</html>