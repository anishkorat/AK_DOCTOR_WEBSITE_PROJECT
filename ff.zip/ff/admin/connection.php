<?php
$server="localhost";
$username="root";
$password="";
$db="ff";

$con=mysqli_connect($server,$username,$password,$db);

if($con)
{
    ?>
    <script>
        alert("CONNECTION IS DONE");
    </script>
    <?php
}
else

{
    ?>
    <script>
        alert(" connection is not done");
    </script>
    <?php
}
?>