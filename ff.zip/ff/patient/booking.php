<?php if(!isset($_SESSION)){
	session_start();
	}  
?>
<?php
$doc_id = isset($_GET['doc_id'])?$_GET['doc_id']:"";
?>
   <?php
    include 'connection.php';
   $sql="SELECT doc_id,dname,dob,age,phone,gender,expertise,ads,userid,email,pwd FROM doctor WHERE doc_id = $doc_id ";

   $result = $con->query($sql);
							if ($result->num_rows > 0) 
							{
							    // output data of each row
							    while($row  = $result->fetch_assoc()) 
							{
							        $doc_id   = $row["doc_id"];
							        $name 	= $row["dname"];
							        $expertise 	= $row["expertise"];
							        $contact 	= $row["phone"];
							       
							        $userid = $row["userid"];
							    }
							}
							
			$con->close(); 


   ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Appoinment</title>
    <link rel = "stylesheet" 
         href = "https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" 
         integrity = "sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" 
         crossorigin = "anonymous">
         <script src="/scripts/snippet-javascript-console.min.js?v=1"></script>
    <style>
       
    </style>

    <script type="text/javascript">
   function fun(){
    var regEx = /^[A-Za-z]+$/;
        var name=document.myform.uname.value;
        var mob=document.myform.ucontact.value;

        if(!isNaN(name))
        {
            alert("PLEASE ENTER LETTERS ONLY.")
            return false;
        }
        else if(isNaN(mob) || mob == "" || (mob.length == 1) || (mob.length == 2) || (mob.length == 3)|| (mob.length == 4)|| (mob.length == 5)|| (mob.length == 6)|| (mob.length == 7)|| (mob.length == 8)|| (mob.length == 9))
        {

            alert("ENTER THE VALID MOBIEL NUMBER(LIKE :: 9879936272)");
            return false;
        }
        else
        {
            return true;
        }
   }
        
    </script>
</head>
<body>


    <div class="container">
   
   
        <form action="#" method="POST" onsubmit="return fun()" enctype="multipath/form-data" name="myform">
        <div class="form-group">

            <div class="row">
            <label for="" class="control-label col-sm-2">Dr. Name:</label>
            <input type="text" class="form-control col-sm-10" name="dname" value="<?php echo $name; ?>">
            </div><br>
            

            <div class="row">
            <label for="" class="control-label col-sm-2" >Contact:</label>
            <input type="text" class="form-control col-sm-10 " name="dcontact" value="<?php echo $contact; ?>">
            </div><br>

            <div class="row">
            <label  class="control-label col-sm-2">Category:</label>
            <input type="text" class="form-control col-sm-10" name="cate" value="<?php echo $expertise; ?>" />
            </div><br>

            <div class="row">
            <label class="control-label col-sm-2">Your Name:</label>
            <input type="text" class="form-control col-sm-10" name="uname" required>
            </div><br>

            <div class="row">
            <label for="" class="control-label col-sm-2">Contact:</label>
            <input type="text" class="form-control col-sm-10" name="ucontact">
            </div><br>

            <div class="row">
            <label for="" class="control-label col-sm-2">E-mail:</label>
            <input type="email" class="form-control col-sm-10" name="email" required>
            </div><br>

            <div class="row">
            <label for="" class="control-label col-sm-2">Address:</label>
            <textarea  class="md-textarea form-control col-sm-10" rows="2" placeholder="Address" name="ads" required></textarea>
            </div><br>

            <div class="row">
            <label class="control-label col-sm-2" > Date:</label>
            <input type="date" class="form-control col-sm-10" name="txtDate" id="txtDate" required>
            
            </div><br>

            <div class="row">
            <label for="" class="control-label col-sm-2">Time:</label>
            <select class="form-control input-sm  col-sm-10" name="time" style="padding:0 7px 3px;" required="">
                    <option value="">-select-</option>
                    <option value="12:00 AM">12:00 AM</option>
                    <option value="12:30 AM">12:30 AM</option>
                    <option value="01:00 AM">01:00 AM</option>
                    <option value="01:30 AM">01:30 AM</option>
                    <option value="02:00 AM">02:00 AM</option>
                    <option value="02:30 AM">02:30 AM</option>
                   

                  </select>
            </div><br>
            
            <div class="row">
            <label for="" class="control-label col-sm-2" style="visibility:hidden;" >Userid:</label>
            <input name="userid"  type="hidden" class="form-control col-sm-10" value="<?php echo $userid; ?>">
            </div>

            <button name="submit" class="btn btn-dark " type="submit" style="padding:10px;border-radius:3px;margin-right:;">Confirm</button> 
             <!-- <a href="search_doc.php"> 
              <button name="" class="btn btn-link" type="" style="padding:10px;border-radius:3px;margin-right:-150px;">Cancel
              </button> 
            </a> -->  
            <a href="search_doc.php">
              <input type="button" value="Cancle" class="btn btn-dark" style="padding:10px;border-radius:3px;">
            </a>
        </div>
       </form>
   
      
      
 
           
                
       
</div>


<script type="text/javascript">
        var today = new Date().toISOString().split('T')[0];
        document.getElementsByName("txtDate")[0].setAttribute('min', today);
    </script>

<?php
 include 'connection.php';


  /*if(isset($_POST['submit']))

{

   $dname=mysqli_real_escape_string($con, $_POST['dname']);
    $dcontact=mysqli_real_escape_string($con, $_POST['dcontact']);
    $expertise=mysqli_real_escape_string($con, $_POST['expertise']);
    $pname=mysqli_real_escape_string($con, $_POST['pname']);
    $pcontact=mysqli_real_escape_string($con, $_POST['pcontact']);
    $email=mysqli_real_escape_string($con, $_POST['email']);
    $address=mysqli_real_escape_string($con, $_POST['address']);
  
    $date=mysqli_real_escape_string($con, $_POST['date']);
    $time=mysqli_real_escape_string($con, $_POST['time']);
    $userid=mysqli_real_escape_string($con, $_POST['userid']);
    
    
    $insertquery="insert into booking(dname,dcontact,expertise,pname,pcontact,email,address,date,time,userid) values ('$dname','$dcontact','$expertise','$pname','$pcontact','$email','$address','$date','$time','$userid')";
    $iquery = mysqli_query($con, $insertquery);
    if($iquery)
    {
            ?>
            <script>
                alert("INSERTED IS DONE");
            </script>
            <?php
                    }
     else

    {
            ?>
            <script>
                alert("inserted not done");
            </script>
            <?php
    }  

} */

if(isset($_POST['submit'])){
							

  $sql="INSERT INTO booking(dname,dcontact,expertise,pname,pcontact,email,address,date,time,userid) VALUES('" . $_POST["dname"] . "','" . $_POST["dcontact"] . "','" . $_POST["cate"] . "','" . $_POST["uname"] . "','". $_POST["ucontact"] . "','". $_POST["email"] . "','". $_POST["ads"] . "','". $_POST["txtDate"] . "','". $_POST["time"] . "','" . $_POST["userid"] . "' )";

    if ($con->query($sql) === TRUE) {
        echo "<script>alert('Your booking has been accepted!');</script>";
    } else {
        echo "<script>alert('There was an Error')<script>";
    }

    $con->close();

  }
?>
</body>
</html>
<!-- <div class="container">
    <center>
        <table>
       
     <div class="formstyle" style="float: right;padding:20px;border: 1px solid lightgrey;margin-right:415px; margin-bottom:30px;background-color:#f3f3f8;color:#141313;"> 

            <form action="#" method="post" class="text-center" enctype="multipath/form-data">

            
              <tr>
                <td><label for="">Dr. Name: </label></td>
                <td><input type="text" class="form-control" name="dname"></td>
              </tr>
           

             
              <tr>
                <td><label for="">Contact:  </label></td>
                <td><input type="text"  name="dcontact"></td>
              </tr>
            
            
         
              <tr>
                <td><label for="">Category: </label></td>
                <td><input type="text" class="form-control" name="cate"></td>
              </tr>
            

              <tr>
                <td><label for="u1">Your Name: </label></td>
                <td><input type="text" class="form-control" name="uname" id="u1"></td>
              </tr>
           

      
              <tr>
                <td><label for="">Contact: </label></td>
                <td><input type="text" class="form-control" name="ucontact"></td>
              </tr>
          

           
              <tr>
                <td><label for="">E-mail: </label></td>
                <td><input type="email" class="form-control" name="email"></td>
              </tr>
        

            
              <tr>
                <td><label for=""> Address: </label></td>
                <td><textarea  class="md-textarea form-control" rows="2" placeholder="Address" name="ads" required></textarea></td>
              </tr>
          

            
              <tr>
                <td><label for=""> Date: </label></td>
                <td><input type="date" class="form-control" name="date"></td>
              </tr>
           

     
              <tr>
                <td><label for="">Time: </label></td>
                <td>
                <select class="form-control input-sm" name="time" style="padding:0 7px 3px;" >
                    <option>-select-</option>
                    <option value="">12:00 AM</option>
                    <option value="">12:30 AM</option>
                    <option value="">01:00 AM</option>
                    <option value="">01:30 AM</option>
                    <option value="">02:00 AM</option>
                    <option value="">02:30 AM</option>
                   

                  </select>
                </td>
              </tr>
            

            <div>
                <tr>
                    <td>
                    <button type="submit" class="btn " style="background-color: #2B3856;;color: aliceblue;" name="sub" disabled>REGISTER</button>
                    </td> 
                    <td>
                        <a href="search_doctor.php"><button name="" type="" class="btn " style="padding-right:5px;border-radius:3px;margin-right:-150px;background-color: #2B3856;;color: aliceblue;">Cancel</button></a> <br>
                    </td> 
            </tr>
               
            </div>
           
            
            </form>
         
         
        </table>
        </center>
       
    </div> -->